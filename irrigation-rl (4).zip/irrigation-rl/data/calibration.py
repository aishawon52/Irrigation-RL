"""
calibration.py

Optional: derive IrrigationEnv soil parameters (field_capacity,
wilting_point) and weather-regime severity from real data instead of
using the defaults in envs/irrigation_env.py / envs/weather_regimes.py.

This is a template -- the exact calibration procedure depends on what
the real dataset actually measures (e.g. volumetric soil moisture in
% vs the env's normalized [0,1] scale). Fill in once a dataset is
selected.
"""

import numpy as np


def normalize_soil_moisture(raw_moisture: np.ndarray, field_capacity_raw: float,
                             wilting_point_raw: float) -> np.ndarray:
    """Rescale raw volumetric soil moisture readings into the env's
    normalized [wilting_point, field_capacity] -> [0,1]-ish convention.
    Adjust once you know the real dataset's units (e.g. % or cm3/cm3)."""
    return (raw_moisture - wilting_point_raw) / (field_capacity_raw - wilting_point_raw)


def estimate_regime_severity(weather_df, normal_years, target_years):
    """
    Compare rainfall/temperature statistics between a 'normal' baseline
    period and a candidate drought/heatwave period in the real data, to
    calibrate how aggressive the synthetic regime overrides in
    envs/weather_regimes.py should be (rather than guessing offsets).

    Returns a dict of summary stats useful for setting REGIMES overrides,
    e.g. {"rainfall_ratio": 0.55, "temp_delta": 3.2}.
    """
    normal_df = weather_df[weather_df["year"].isin(normal_years)]
    target_df = weather_df[weather_df["year"].isin(target_years)]

    rainfall_ratio = target_df["rainfall"].mean() / max(normal_df["rainfall"].mean(), 1e-6)
    temp_delta = target_df["temperature"].mean() - normal_df["temperature"].mean()

    return {
        "rainfall_ratio": float(rainfall_ratio),
        "temp_delta": float(temp_delta),
        "normal_rainfall_mean": float(normal_df["rainfall"].mean()),
        "target_rainfall_mean": float(target_df["rainfall"].mean()),
        "normal_temp_mean": float(normal_df["temperature"].mean()),
        "target_temp_mean": float(target_df["temperature"].mean()),
    }
