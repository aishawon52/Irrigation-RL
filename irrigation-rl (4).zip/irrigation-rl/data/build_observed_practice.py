"""
build_observed_practice.py

Takes the raw weather CSV downloaded from Open-Meteo (temperature,
rainfall, ET0, humidity) and derives a plausible daily irrigation_mm
column using a standard threshold-based water-balance rule: irrigate
enough to bring soil moisture back to field capacity whenever it would
otherwise drop below a trigger threshold.

This is NOT a substitute for a real recorded irrigation log -- it's a
documented, reproducible stand-in ("simulated observed practice") for
when no such log is available, so the observed_practice benchmark in
evaluate_all.py has something real-weather-driven to run against
instead of being skipped entirely. Say so explicitly in your paper's
methods section if you use this.

Usage:
    python -m data.build_observed_practice \
        --weather-csv data/raw/weather_dhaka_2023.csv \
        --out data/raw/season_dhaka_2023.csv \
        --trigger 0.40 --field-capacity 1.0 --wilting-point 0.15
"""

import argparse
import re
import pandas as pd
import numpy as np


def load_open_meteo_csv(path: str) -> pd.DataFrame:
    """Open-Meteo's CSV export (format=csv) puts a small metadata
    block (latitude/longitude/elevation/timezone) before the real
    header row, and appends unit suffixes like '(mm)' to column
    names. This finds the real header row (the one starting with
    'time') and strips the unit suffixes, so downstream code can rely
    on plain names like 'precipitation_sum' regardless of which exact
    export format was downloaded."""
    with open(path, "r", encoding="utf-8") as f:
        lines = f.readlines()

    header_idx = None
    for i, line in enumerate(lines):
        first_field = line.split(",")[0].strip().strip('"').lower()
        if first_field == "time":
            header_idx = i
            break

    if header_idx is None:
        # Not an Open-Meteo-style file with a metadata preamble --
        # assume it's already a plain CSV with the header on line 0.
        header_idx = 0

    df = pd.read_csv(path, skiprows=header_idx)
    df.columns = [re.sub(r"\s*\(.*?\)\s*$", "", c).strip() for c in df.columns]
    return df


def derive_irrigation(df: pd.DataFrame, trigger: float, field_capacity: float,
                       wilting_point: float, initial_moisture: float = 0.65) -> pd.DataFrame:
    moisture = initial_moisture
    irrigation_mm = []

    for _, row in df.iterrows():
        # same water-balance form as IrrigationEnv.step, before any irrigation
        moisture = moisture + row["precipitation_sum"] / 100.0 - row["et0_fao_evapotranspiration_sum"] / 100.0
        moisture = np.clip(moisture, 0.0, field_capacity)

        if moisture < trigger:
            # irrigate back to field capacity
            deficit_fraction = field_capacity - moisture
            mm = deficit_fraction * 100.0  # matches the /100 scaling in IrrigationEnv
            mm = float(np.clip(mm, 0.0, 30.0))  # cap at env's max_irrigation
        else:
            mm = 0.0

        moisture = np.clip(moisture + mm / 100.0, wilting_point, field_capacity)
        irrigation_mm.append(mm)

    df = df.copy()
    df["irrigation_mm"] = irrigation_mm
    return df


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--weather-csv", required=True)
    parser.add_argument("--out", required=True)
    parser.add_argument("--trigger", type=float, default=0.40)
    parser.add_argument("--field-capacity", type=float, default=1.0)
    parser.add_argument("--wilting-point", type=float, default=0.15)
    args = parser.parse_args()

    df = load_open_meteo_csv(args.weather_csv)
    df = df.rename(columns={"time": "date"})

    out = derive_irrigation(
        df, trigger=args.trigger, field_capacity=args.field_capacity,
        wilting_point=args.wilting_point,
    )
    out.to_csv(args.out, index=False)
    print(f"Saved {len(out)} rows to {args.out}")
    print(f"Total irrigation applied: {out['irrigation_mm'].sum():.1f} mm")
    print(f"Days irrigated: {(out['irrigation_mm'] > 0).sum()} / {len(out)}")


if __name__ == "__main__":
    main()
