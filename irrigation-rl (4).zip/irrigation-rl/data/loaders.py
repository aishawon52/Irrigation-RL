"""
loaders.py

Converts a real dataset (weather + irrigation + yield records) into
the formats IrrigationEnv and observed_practice.py expect:

  - weather_series: list[dict] with keys temperature, rainfall,
    evapotranspiration, humidity, one entry per day.
  - irrigation_series: list[float], mm applied per day, one entry
    per day, aligned with weather_series.

This file is intentionally left as a template with a CSV-based
reference implementation, since the exact column names/units depend
on whichever dataset you end up using (e.g. the 2025 cotton
irrigation dataset, or a NASA POWER / Open-Meteo pull). Adjust the
COLUMN_MAP and unit conversions below once you have the real file in
data/raw/.
"""

import pandas as pd

# Map your dataset's actual column names to the fields IrrigationEnv
# needs. Edit this once you have the real CSV's header.
COLUMN_MAP = {
    "date": "date",
    "temperature": "temperature_2m_mean",              # deg C, Open-Meteo archive API
    "rainfall": "precipitation_sum",                   # mm/day, Open-Meteo archive API
    "evapotranspiration": "et0_fao_evapotranspiration_sum",  # mm/day, FAO-56 Penman-Monteith
    "humidity": "relative_humidity_2m_mean",           # %, Open-Meteo archive API
    "irrigation": "irrigation_mm",                     # mm/day, from data/build_observed_practice.py
}


def load_weather_and_irrigation(csv_path: str, season_start: str, season_end: str):
    """
    Parameters
    ----------
    csv_path : str
        Path to a CSV with daily records (see COLUMN_MAP for expected
        columns, renamed as needed).
    season_start, season_end : str
        Date strings (YYYY-MM-DD) bounding one growing season within
        the file, so multiple seasons/years/fields can be sliced out
        of one larger raw file.

    Returns
    -------
    weather_series : list[dict]
    irrigation_series : list[float]
    """
    df = pd.read_csv(csv_path, parse_dates=[COLUMN_MAP["date"]])
    df = df.rename(columns={v: k for k, v in COLUMN_MAP.items()})

    mask = (df["date"] >= season_start) & (df["date"] <= season_end)
    season_df = df.loc[mask].sort_values("date").reset_index(drop=True)

    if season_df.empty:
        raise ValueError(
            f"No rows found between {season_start} and {season_end} in {csv_path}"
        )

    weather_series = season_df[
        ["temperature", "rainfall", "evapotranspiration", "humidity"]
    ].to_dict(orient="records")

    irrigation_series = season_df["irrigation"].tolist()

    return weather_series, irrigation_series


def list_available_seasons(csv_path: str, date_col: str = None):
    """Convenience helper: print the date range and any obvious
    season/field/year grouping columns to help you figure out how to
    slice season_start/season_end above. Run this once interactively
    after downloading a new dataset."""
    date_col = date_col or COLUMN_MAP["date"]
    df = pd.read_csv(csv_path, parse_dates=[date_col])
    print(f"Date range: {df[date_col].min()} to {df[date_col].max()}")
    print(f"Columns: {list(df.columns)}")
    return df
