"""
significance.py

Pairwise statistical comparison of algorithms within each regime,
using per-seed mean yield/water-productivity as the sample (n=5 per
algorithm, matching SEEDS in config.py). Uses Mann-Whitney U (no
normality assumption) since 5 seeds is too few to safely assume a
normal distribution; falls back to reporting means/stds if the test
degenerates (e.g. identical values).

Usage:
    python -m evaluation.significance
"""

import itertools
import os

import pandas as pd
from scipy.stats import mannwhitneyu

from training.config import RESULTS_DIR

RL_ALGOS = ["ppo", "sac", "a2c", "dqn"]


def load_full_results():
    path = os.path.join(RESULTS_DIR, "tables", "full_results.csv")
    if not os.path.exists(path):
        raise FileNotFoundError(
            f"{path} not found -- run evaluation.evaluate_all first."
        )
    return pd.read_csv(path)


def pairwise_tests(df: pd.DataFrame, metric: str = "yield_mean"):
    """For each regime, run pairwise Mann-Whitney U tests between all
    RL algorithm pairs on the given metric, using per-seed values."""
    rows = []
    regimes = df["regime"].dropna().unique()

    for regime in regimes:
        regime_df = df[(df["regime"] == regime) & (df["method"].isin(RL_ALGOS))]

        for algo_a, algo_b in itertools.combinations(RL_ALGOS, 2):
            values_a = regime_df[regime_df["method"] == algo_a][metric].dropna().values
            values_b = regime_df[regime_df["method"] == algo_b][metric].dropna().values

            if len(values_a) < 2 or len(values_b) < 2:
                continue

            try:
                stat, p_value = mannwhitneyu(values_a, values_b, alternative="two-sided")
            except ValueError:
                stat, p_value = float("nan"), float("nan")

            rows.append({
                "regime": regime,
                "metric": metric,
                "algo_a": algo_a,
                "algo_b": algo_b,
                "mean_a": values_a.mean(),
                "mean_b": values_b.mean(),
                "u_statistic": stat,
                "p_value": p_value,
                "significant_at_0.05": p_value < 0.05 if p_value == p_value else False,
            })

    return pd.DataFrame(rows)


def main():
    df = load_full_results()
    out_dir = os.path.join(RESULTS_DIR, "tables")

    for metric in ["yield_mean", "water_productivity_mean"]:
        results = pairwise_tests(df, metric=metric)
        out_path = os.path.join(out_dir, f"significance_{metric}.csv")
        results.to_csv(out_path, index=False)
        print(f"Saved {len(results)} pairwise comparisons to {out_path}")


if __name__ == "__main__":
    main()
