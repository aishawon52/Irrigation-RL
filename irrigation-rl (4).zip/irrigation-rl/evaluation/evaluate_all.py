"""
evaluate_all.py

Loads every trained model (algorithm x seed) plus the baseline
policies, rolls each out across all weather regimes, and aggregates
results into a single tidy DataFrame written to
results/tables/full_results.csv.

This table is the source for every subsequent table/figure in the
paper (main comparison table, cross-regime degradation, Pareto plot).

Usage:
    python -m evaluation.evaluate_all
    python -m evaluation.evaluate_all --n-episodes 30
"""

import argparse
import os

import pandas as pd
from stable_baselines3 import PPO, SAC, A2C, DQN

from training.config import SEEDS, model_dir, RESULTS_DIR, ENV_KWARGS
from evaluation.rollout import run_episodes
from evaluation.metrics import aggregate_episode_metrics
from baselines.fixed_policy import FixedPolicy
from baselines.threshold_policy import ThresholdPolicy
from baselines.random_policy import RandomPolicy

REGIMES = ["normal", "drought", "heatwave", "excess_rain"]

SB3_LOADERS = {"ppo": PPO, "sac": SAC, "a2c": A2C, "dqn": DQN}
DISCRETE_ALGOS = {"dqn"}


def load_rl_model(algo: str, seed: int):
    save_dir = model_dir(algo, seed)
    best_path = os.path.join(save_dir, "best_model.zip")
    final_path = os.path.join(save_dir, "final_model.zip")
    path = best_path if os.path.exists(best_path) else final_path
    if not os.path.exists(path):
        raise FileNotFoundError(f"No saved model found for {algo} seed={seed} at {path}")
    return SB3_LOADERS[algo].load(path)


def evaluate_rl_models(n_episodes: int, seeds=SEEDS, real_weather_series=None, real_regime_name="real_data"):
    rows = []
    for algo in SB3_LOADERS:
        for seed in seeds:
            try:
                model = load_rl_model(algo, seed)
            except FileNotFoundError as e:
                print(f"[skip] {e}")
                continue

            discrete = algo in DISCRETE_ALGOS
            for regime in REGIMES:
                episodes = run_episodes(
                    model, regime=regime, n_episodes=n_episodes,
                    seed_start=seed * 100, discrete=discrete,
                )
                summary = aggregate_episode_metrics(episodes)
                summary.update({"method": algo, "seed": seed, "regime": regime})
                rows.append(summary)
                print(f"[eval] {algo} seed={seed} regime={regime}: "
                      f"yield={summary['yield_mean']:.2f} "
                      f"water={summary['water_used_mean']:.2f}")

            # Same trained model, same seed, but rolled out on the exact
            # real weather series instead of synthetic "normal" regime --
            # this is what makes the observed_practice comparison a fair
            # water-saving comparison rather than synthetic-vs-real.
            if real_weather_series is not None:
                episodes = run_episodes(
                    model, regime="normal", n_episodes=n_episodes,
                    seed_start=seed * 100, discrete=discrete,
                    weather_series_fn=lambda ep: real_weather_series,
                )
                summary = aggregate_episode_metrics(episodes)
                summary.update({"method": algo, "seed": seed, "regime": real_regime_name})
                rows.append(summary)
                print(f"[eval] {algo} seed={seed} regime={real_regime_name}: "
                      f"yield={summary['yield_mean']:.2f} "
                      f"water={summary['water_used_mean']:.2f}")
    return rows


def evaluate_baselines(n_episodes: int, real_weather_series=None, real_regime_name="real_data"):
    baseline_policies = {
        "fixed_10mm": FixedPolicy(mm_per_day=10.0),
        "fixed_15mm": FixedPolicy(mm_per_day=15.0),
        "threshold": ThresholdPolicy(moisture_threshold=0.40, irrigation_amount=15.0),
        "random": RandomPolicy(max_irrigation=ENV_KWARGS["max_irrigation"], seed=0),
    }

    rows = []
    for name, policy in baseline_policies.items():
        for regime in REGIMES:
            episodes = run_episodes(
                policy, regime=regime, n_episodes=n_episodes, seed_start=0,
            )
            summary = aggregate_episode_metrics(episodes)
            summary.update({"method": name, "seed": None, "regime": regime})
            rows.append(summary)
            print(f"[eval] {name} regime={regime}: "
                  f"yield={summary['yield_mean']:.2f} "
                  f"water={summary['water_used_mean']:.2f}")

        if real_weather_series is not None:
            episodes = run_episodes(
                policy, regime="normal", n_episodes=n_episodes, seed_start=0,
                weather_series_fn=lambda ep: real_weather_series,
            )
            summary = aggregate_episode_metrics(episodes)
            summary.update({"method": name, "seed": None, "regime": real_regime_name})
            rows.append(summary)
            print(f"[eval] {name} regime={real_regime_name}: "
                  f"yield={summary['yield_mean']:.2f} "
                  f"water={summary['water_used_mean']:.2f}")
    return rows


def evaluate_observed_practice(n_episodes: int, irrigation_series=None, weather_series_fn=None):
    """Real-practice benchmark. Requires either a fixed irrigation
    series (paired with synthetic weather) or, more realistically,
    both a real irrigation series AND a matching real weather series
    loaded via data/loaders.py. Skipped by default until real data is
    wired in -- see data/loaders.py."""
    if irrigation_series is None:
        print("[skip] observed_practice: no real irrigation series provided yet "
              "(wire this up once a real dataset is loaded via data/loaders.py)")
        return []

    from baselines.observed_practice import ObservedPracticePolicy
    policy = ObservedPracticePolicy(irrigation_series)

    episodes = run_episodes(
        policy, regime="normal", n_episodes=n_episodes, seed_start=0,
        weather_series_fn=weather_series_fn,
    )
    summary = aggregate_episode_metrics(episodes)
    summary.update({"method": "observed_practice", "seed": None, "regime": "real_data"})
    return [summary]


def main(n_episodes: int, real_weather_csv: str = None,
         season_start: str = None, season_end: str = None):
    weather_series = None
    irrigation_series = None

    if real_weather_csv is not None:
        from data.loaders import load_weather_and_irrigation
        try:
            weather_series, irrigation_series = load_weather_and_irrigation(
                real_weather_csv, season_start, season_end,
            )
            print(f"[real-data] loaded {len(weather_series)} days from {real_weather_csv} "
                  f"({season_start} to {season_end})")
        except KeyError as e:
            print(f"[error] {real_weather_csv} is missing an expected column: {e}")
            print("        If this is a raw Open-Meteo weather pull with no irrigation "
                  "column yet, run this first:")
            print(f"        python -m data.build_observed_practice "
                  f"--weather-csv {real_weather_csv} --out data/raw/season_with_irrigation.csv")
            print("        then point --real-weather-csv at that output file instead.")
            raise

    rows = []
    rows.extend(evaluate_rl_models(n_episodes, real_weather_series=weather_series))
    rows.extend(evaluate_baselines(n_episodes, real_weather_series=weather_series))
    rows.extend(evaluate_observed_practice(
        n_episodes, irrigation_series=irrigation_series,
        weather_series_fn=(lambda ep: weather_series) if weather_series is not None else None,
    ))

    df = pd.DataFrame(rows)
    out_dir = os.path.join(RESULTS_DIR, "tables")
    os.makedirs(out_dir, exist_ok=True)
    out_path = os.path.join(out_dir, "full_results.csv")
    df.to_csv(out_path, index=False)
    print(f"\nSaved {len(df)} rows to {out_path}")
    return df


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--n-episodes", type=int, default=20)
    parser.add_argument("--real-weather-csv", default=None,
                         help="Path to a CSV with real daily weather + irrigation "
                              "(see data/loaders.py COLUMN_MAP). If omitted, the "
                              "observed_practice benchmark is skipped as before.")
    parser.add_argument("--season-start", default=None, help="YYYY-MM-DD")
    parser.add_argument("--season-end", default=None, help="YYYY-MM-DD")
    args = parser.parse_args()
    main(n_episodes=args.n_episodes, real_weather_csv=args.real_weather_csv,
         season_start=args.season_start, season_end=args.season_end)
