"""
rollout.py

Runs a trained SB3 model OR a hand-written baseline policy for N
episodes under a specified weather regime, using IrrigationEnv
directly (not vectorized), and collects per-episode metrics.

Both SB3 models and the baseline classes in baselines/ expose the
same `.predict(observation, deterministic=True) -> (action, state)`
interface, so this function works unmodified for either.
"""

import numpy as np

from envs.weather_regimes import make_env_with_regime
from envs.discrete_wrapper import DiscreteIrrigationWrapper
from evaluation.metrics import episode_metrics
from training.config import ENV_KWARGS, DISCRETE_LEVELS_MM


def run_episodes(
    policy,
    regime: str,
    n_episodes: int = 20,
    seed_start: int = 0,
    discrete: bool = False,
    weather_series_fn=None,
):
    """
    Parameters
    ----------
    policy : object with .predict(obs, deterministic=True) -> (action, state)
        An SB3 model or one of the baselines/ policy classes.
    regime : str
        One of "normal", "drought", "heatwave", "excess_rain" -- ignored
        if weather_series_fn is provided (real-data replay mode).
    n_episodes : int
        Number of episodes to roll out.
    seed_start : int
        First seed used; seeds increment per episode for reproducibility
        without repeating the exact same weather trajectory.
    discrete : bool
        Wrap the env with DiscreteIrrigationWrapper (only needed if the
        given policy expects discrete actions, e.g. a DQN model).
    weather_series_fn : callable or None
        If provided, called once as weather_series_fn(episode_index) ->
        list[dict] to build a real-weather-driven env instead of a
        synthetic regime (used for the observed-practice benchmark and
        for real-data calibrated evaluation).

    Returns
    -------
    list[dict] : one metrics dict per completed episode.
    """
    results = []

    for ep in range(n_episodes):
        seed = seed_start + ep

        if weather_series_fn is not None:
            from envs.irrigation_env import IrrigationEnv
            kwargs = dict(ENV_KWARGS)
            kwargs["seed"] = seed
            kwargs["weather_series"] = weather_series_fn(ep)
            env = IrrigationEnv(**kwargs)
        else:
            kwargs = dict(ENV_KWARGS)
            kwargs["seed"] = seed
            env = make_env_with_regime(regime, kwargs)

        if discrete:
            env = DiscreteIrrigationWrapper(env, levels_mm=DISCRETE_LEVELS_MM)

        if hasattr(policy, "reset"):
            policy.reset()

        obs, info = env.reset(seed=seed)
        terminated = truncated = False
        final_info = info

        while not (terminated or truncated):
            action, _ = policy.predict(obs, deterministic=True)
            obs, reward, terminated, truncated, info = env.step(action)
            final_info = info

        results.append(episode_metrics(final_info))
        env.close()

    return results
