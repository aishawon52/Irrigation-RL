"""
metrics.py

Computes the paper's headline metrics from a completed episode's
final info dict (as returned by IrrigationEnv.step on termination)
plus the per-episode running totals.
"""

import numpy as np

# Minimum viable yield threshold used for the "% episodes below
# viable yield" robustness metric. Calibrate this once you have a
# sense of the achievable yield range from a few exploratory runs.
MIN_VIABLE_YIELD = 20.0


def episode_metrics(final_info: dict) -> dict:
    """Extract the standard metric set from a terminal step's info dict."""
    return {
        "yield": final_info.get("final_yield", np.nan),
        "water_used": final_info.get("cumulative_water", np.nan),
        "water_productivity": final_info.get("water_productivity", np.nan),
        "cumulative_stress": final_info.get("cumulative_stress", np.nan),
        "cumulative_drainage": final_info.get("cumulative_drainage", np.nan),
    }


def aggregate_episode_metrics(episode_metric_dicts: list[dict]) -> dict:
    """Aggregate a list of per-episode metric dicts into mean/std
    summary statistics plus the robustness indicator."""
    if not episode_metric_dicts:
        return {}

    keys = episode_metric_dicts[0].keys()
    summary = {}
    for key in keys:
        values = np.array([m[key] for m in episode_metric_dicts], dtype=float)
        summary[f"{key}_mean"] = float(np.nanmean(values))
        summary[f"{key}_std"] = float(np.nanstd(values))

    yields = np.array([m["yield"] for m in episode_metric_dicts], dtype=float)
    summary["pct_below_viable_yield"] = float(
        100.0 * np.mean(yields < MIN_VIABLE_YIELD)
    )

    # water_productivity is NaN for episodes where cumulative_water was
    # below MIN_WATER_FOR_PRODUCTIVITY (see IrrigationEnv.step) --
    # nanmean/nanstd above already exclude these correctly, but report
    # how many were excluded so a policy that skips irrigation in most
    # episodes is visible in the table rather than silently dropped.
    wp_values = np.array([m["water_productivity"] for m in episode_metric_dicts], dtype=float)
    summary["pct_negligible_water"] = float(100.0 * np.mean(np.isnan(wp_values)))

    summary["n_episodes"] = len(episode_metric_dicts)
    return summary
