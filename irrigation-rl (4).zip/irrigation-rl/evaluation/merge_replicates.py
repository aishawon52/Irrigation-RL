"""
merge_replicates.py

Combines results/tables/full_results.csv from several replicate runs
(each produced with a different IRRIGATION_RUN_TAG, see
training/config.py) into one table, then reports variance BETWEEN
replicate runs -- not just between seeds within a single run -- for
each (method, regime). This is what actually justifies a claim like
"PPO needs ~500k+ steps to converge": that claim needs to hold up
across independent full pipeline runs, not just across the 5 seeds
inside one run.

Usage:
    # after producing results_2M_rep1/, results_2M_rep2/, results_2M_rep3/
    # (each via: set IRRIGATION_RUN_TAG=2M_rep1 && python run_experiment.py ...)
    python -m evaluation.merge_replicates --tags 2M_rep1 2M_rep2 2M_rep3 \
        --out results/tables/merged_2M_replicates.csv
"""

import argparse
import os

import pandas as pd

from training.config import PROJECT_ROOT


def load_replicate(tag: str) -> pd.DataFrame:
    path = os.path.join(PROJECT_ROOT, f"results_{tag}", "tables", "full_results.csv")
    if not os.path.exists(path):
        raise FileNotFoundError(
            f"No results found for tag '{tag}' at {path}. "
            f"Did you run with IRRIGATION_RUN_TAG={tag} set?"
        )
    df = pd.read_csv(path)
    df["run_tag"] = tag
    return df


def main(tags: list[str], out_path: str):
    dfs = [load_replicate(t) for t in tags]
    combined = pd.concat(dfs, ignore_index=True)

    os.makedirs(os.path.dirname(out_path), exist_ok=True)
    combined.to_csv(out_path, index=False)
    print(f"Saved {len(combined)} rows from {len(tags)} replicate runs to {out_path}")

    # Run-to-run variance: average each run's seeds first, THEN look at
    # spread across runs -- this is the number that matters for "is the
    # training-budget effect real or just noise", as opposed to the
    # existing per-run significance tests which only look across seeds.
    per_run_means = (
        combined.groupby(["method", "regime", "run_tag"])["yield_mean"]
        .mean()
        .reset_index()
    )
    run_to_run = (
        per_run_means.groupby(["method", "regime"])["yield_mean"]
        .agg(["mean", "std", "count"])
        .rename(columns={"mean": "yield_mean_across_runs",
                          "std": "yield_std_across_runs",
                          "count": "n_replicate_runs"})
    )
    print("\nRun-to-run variance in yield_mean (across replicate full runs, not seeds):")
    print(run_to_run.round(2).to_string())
    print(
        "\nIf yield_std_across_runs is small relative to the gap you're "
        "reporting between two timestep budgets, the budget effect is "
        "likely real. If it's comparable to or larger than that gap, you "
        "don't have enough replicates yet to distinguish a real effect "
        "from ordinary run-to-run noise."
    )


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--tags", nargs="+", required=True,
                         help="IRRIGATION_RUN_TAG values used for each replicate run")
    parser.add_argument("--out", default="results/tables/merged_replicates.csv")
    args = parser.parse_args()
    main(args.tags, args.out)
