"""
train_a2c.py

Train A2C on IrrigationEnv (continuous action space, "normal" weather
regime). A2C is a cheap on-policy baseline included to show that
PPO's more sophisticated objective (clipped surrogate, GAE) earns its
keep relative to a simpler on-policy actor-critic.

Usage:
    python -m training.train_a2c --seed 42
"""

import argparse
import os

from stable_baselines3 import A2C
from stable_baselines3.common.callbacks import EvalCallback, StopTrainingOnNoModelImprovement

from training.config import (
    A2C_KWARGS, N_ENVS, TOTAL_TIMESTEPS, EVAL_FREQ, EVAL_EPISODES,
    EARLY_STOP_PATIENCE, EARLY_STOP_MIN_EVALS,
    model_dir, tensorboard_dir,
)
from training.env_factory import make_training_env, make_eval_env


def train(seed: int, total_timesteps: int = TOTAL_TIMESTEPS, use_early_stopping: bool = True):
    save_dir = model_dir("a2c", seed)
    tb_dir = tensorboard_dir("a2c")

    train_env = make_training_env(n_envs=N_ENVS, seed=seed, discrete=False, monitor_dir=save_dir)
    eval_env = make_eval_env(seed=seed, discrete=False, monitor_dir=save_dir)

    model = A2C(
        env=train_env,
        seed=seed,
        tensorboard_log=tb_dir,
        **A2C_KWARGS,
    )

    stop_callback = None
    if use_early_stopping:
        stop_callback = StopTrainingOnNoModelImprovement(
            max_no_improvement_evals=EARLY_STOP_PATIENCE,
            min_evals=EARLY_STOP_MIN_EVALS,
            verbose=1,
        )

    eval_callback = EvalCallback(
        eval_env,
        callback_after_eval=stop_callback,
        best_model_save_path=save_dir,
        log_path=save_dir,
        eval_freq=max(EVAL_FREQ // N_ENVS, 1),
        n_eval_episodes=EVAL_EPISODES,
        deterministic=True,
        render=False,
    )

    model.learn(
        total_timesteps=total_timesteps,
        callback=eval_callback,
        tb_log_name=f"seed_{seed}",
        progress_bar=False,
    )
    print(f"[A2C seed={seed}] stopped after {model.num_timesteps} timesteps "
          f"(ceiling was {total_timesteps})")

    final_path = os.path.join(save_dir, "final_model.zip")
    model.save(final_path)
    print(f"[A2C seed={seed}] saved final model to {final_path}")

    train_env.close()
    eval_env.close()


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--seed", type=int, required=True)
    parser.add_argument("--timesteps", type=int, default=TOTAL_TIMESTEPS)
    parser.add_argument("--no-early-stopping", action="store_true",
                         help="Disable StopTrainingOnNoModelImprovement; run the full --timesteps budget.")
    args = parser.parse_args()
    train(seed=args.seed, total_timesteps=args.timesteps,
          use_early_stopping=not args.no_early_stopping)
