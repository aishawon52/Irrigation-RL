"""
train_all.py

Runs training for every (algorithm x seed) combination sequentially.
For real experiments you'll likely want to parallelize this across
processes/machines rather than running it in one script, but this
gives a single reproducible entry point and is fine for smaller
timestep budgets or a first full pass.

Usage:
    python -m training.train_all
    python -m training.train_all --algos ppo sac --seeds 42 123
"""

import argparse
import time

from training.config import SEEDS, TOTAL_TIMESTEPS
from training import train_ppo, train_sac, train_a2c, train_dqn

TRAINERS = {
    "ppo": train_ppo.train,
    "sac": train_sac.train,
    "a2c": train_a2c.train,
    "dqn": train_dqn.train,
}


def main(algos, seeds, timesteps):
    for algo in algos:
        for seed in seeds:
            print(f"\n{'='*60}\nTraining {algo.upper()} | seed={seed}\n{'='*60}")
            start = time.time()
            TRAINERS[algo](seed=seed, total_timesteps=timesteps)
            elapsed = time.time() - start
            print(f"[{algo.upper()} seed={seed}] finished in {elapsed/60:.1f} min")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--algos", nargs="+", default=list(TRAINERS.keys()),
                         choices=list(TRAINERS.keys()))
    parser.add_argument("--seeds", nargs="+", type=int, default=SEEDS)
    parser.add_argument("--timesteps", type=int, default=TOTAL_TIMESTEPS)
    args = parser.parse_args()
    main(args.algos, args.seeds, args.timesteps)
