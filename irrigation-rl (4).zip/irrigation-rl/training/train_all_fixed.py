"""
train_all_fixed.py

Same as train_all.py, but for a *fixed-budget* comparison run: every
algorithm trains for the full timestep budget with no early stopping
at all -- useful when you want every algorithm to explore up to the
same fixed horizon regardless of when its eval reward plateaus,
rather than letting StopTrainingOnNoModelImprovement cut some runs
short.

This does NOT modify train_ppo.py / train_sac.py / train_a2c.py /
train_dqn.py's default behavior -- those still early-stop by default
when called directly or via train_all.py. This script just calls the
same train() functions with use_early_stopping=False.

Usage:
    python -m training.train_all_fixed
    python -m training.train_all_fixed --algos ppo sac --seeds 42 123
    python -m training.train_all_fixed --timesteps 2000000
"""

import argparse
import time

from training.config import SEEDS, FIXED_TIMESTEPS
from training import train_ppo, train_sac, train_a2c, train_dqn

TRAINERS = {
    "ppo": train_ppo.train,
    "sac": train_sac.train,
    "a2c": train_a2c.train,
    "dqn": train_dqn.train,
}


def main(algos, seeds, timesteps):
    for algo in algos:
        for seed in seeds:
            print(f"\n{'='*60}\n"
                  f"Training {algo.upper()} | seed={seed} | "
                  f"fixed {timesteps} timesteps, early stopping OFF\n"
                  f"{'='*60}")
            start = time.time()
            TRAINERS[algo](seed=seed, total_timesteps=timesteps, use_early_stopping=False)
            elapsed = time.time() - start
            print(f"[{algo.upper()} seed={seed}] finished in {elapsed/60:.1f} min "
                  f"(ran the full fixed budget, no early stopping)")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--algos", nargs="+", default=list(TRAINERS.keys()),
                         choices=list(TRAINERS.keys()))
    parser.add_argument("--seeds", nargs="+", type=int, default=SEEDS)
    parser.add_argument("--timesteps", type=int, default=FIXED_TIMESTEPS)
    args = parser.parse_args()
    main(args.algos, args.seeds, args.timesteps)
