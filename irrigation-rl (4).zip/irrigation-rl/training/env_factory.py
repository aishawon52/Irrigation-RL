"""
env_factory.py

Shared helpers for constructing (vectorized, monitored) training and
evaluation environments consistently across all algorithm scripts.
Keeping this in one place avoids subtle mismatches (e.g. one script
forgetting Monitor, or building the env with different kwargs) that
would make the cross-algorithm comparison unfair.

Monitor logging is wired to write monitor.csv into each run's model
directory so plotting/learning_curves.py has something to read as a
lightweight alternative/complement to TensorBoard.
"""

import os

from stable_baselines3.common.env_util import make_vec_env
from stable_baselines3.common.monitor import Monitor

from envs.weather_regimes import make_env_with_regime
from envs.discrete_wrapper import DiscreteIrrigationWrapper
from training.config import ENV_KWARGS, TRAIN_REGIME, DISCRETE_LEVELS_MM


def _base_env_fn(seed=None, discrete=False):
    def _init():
        kwargs = dict(ENV_KWARGS)
        if seed is not None:
            kwargs["seed"] = seed
        env = make_env_with_regime(TRAIN_REGIME, kwargs)
        if discrete:
            env = DiscreteIrrigationWrapper(env, levels_mm=DISCRETE_LEVELS_MM)
        return env
    return _init


def make_training_env(n_envs: int, seed: int, discrete: bool = False, monitor_dir: str = None):
    """Vectorized training environment (SubprocVecEnv/DummyVecEnv under
    the hood, chosen automatically by make_vec_env). If monitor_dir is
    given, each sub-env's episode stats are written to
    {monitor_dir}/{i}.monitor.csv."""
    env_fn = _base_env_fn(seed=seed, discrete=discrete)
    return make_vec_env(env_fn, n_envs=n_envs, seed=seed, monitor_dir=monitor_dir)


def make_eval_env(seed: int, discrete: bool = False, monitor_dir: str = None):
    """Single, monitored environment used by EvalCallback during
    training (separate from the vectorized training env, per SB3
    convention, to get unbiased periodic evaluation)."""
    env_fn = _base_env_fn(seed=seed + 10_000, discrete=discrete)
    env = env_fn()
    filename = os.path.join(monitor_dir, "eval_monitor.csv") if monitor_dir else None
    return Monitor(env, filename=filename)
