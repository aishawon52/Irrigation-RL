"""
config.py

Central configuration for all training runs: seeds, timesteps,
per-algorithm hyperparameters, and shared paths (models, TensorBoard
logs). Keeping this in one place means the paper's "shared
hyperparameters across algorithms" table is a direct dump of this
file, and every training script imports from here rather than
hardcoding values that could drift out of sync between algorithms.
"""

import os

# ---------------------------------------------------------------
# Paths
# ---------------------------------------------------------------

PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

# Optional per-run tag, e.g. set IRRIGATION_RUN_TAG=2M_rep1 before running
# train_all.py/run_experiment.py, so replicate runs (needed to distinguish
# a real training-budget effect from ordinary run-to-run variance) write
# to models_2M_rep1/, results_2M_rep1/, etc. instead of overwriting the
# default models/ and results/ folders. Leave unset for normal single-run use.
RUN_TAG = os.environ.get("IRRIGATION_RUN_TAG", "").strip()
_suffix = f"_{RUN_TAG}" if RUN_TAG else ""

MODELS_DIR = os.path.join(PROJECT_ROOT, f"models{_suffix}")
TENSORBOARD_DIR = os.path.join(PROJECT_ROOT, "logs", f"tensorboard{_suffix}")
RESULTS_DIR = os.path.join(PROJECT_ROOT, f"results{_suffix}")

# ---------------------------------------------------------------
# Experiment-wide settings
# ---------------------------------------------------------------

SEEDS = [42, 123, 456, 789, 1024]          # 5 seeds per algorithm
TOTAL_TIMESTEPS = 1_500_000                 # generous CEILING only -- see early stopping below;
                                             # runs are expected to stop well before this in practice
N_ENVS = 4                                  # parallel envs for vectorized training
EVAL_FREQ = 10_000                          # steps between periodic eval callbacks
EVAL_EPISODES = 10                          # episodes per periodic eval

# ---------------------------------------------------------------
# Early stopping
# ---------------------------------------------------------------
# Training is no longer driven by a fixed timestep target: EvalCallback
# runs every EVAL_FREQ steps, and StopTrainingOnNoModelImprovement (wired
# in by each training script) halts the run once the mean eval reward
# has failed to improve for EARLY_STOP_PATIENCE consecutive eval rounds.
# EARLY_STOP_MIN_EVALS gives a warm-up period so early, noisy evaluations
# can't trigger a premature stop before the policy has had a chance to
# learn anything. TOTAL_TIMESTEPS above remains only as a hard ceiling
# in case a run genuinely never plateaus.
EARLY_STOP_PATIENCE = 10                    # eval rounds with no improvement before stopping
EARLY_STOP_MIN_EVALS = 10                   # eval rounds required before stopping can trigger

# Separate, independent budget for train_all_fixed.py, which trains every
# algorithm for this many timesteps with early stopping disabled entirely
# (a fixed-budget run, as opposed to TOTAL_TIMESTEPS above which is only a
# safety ceiling for the early-stopping runs).
FIXED_TIMESTEPS = 2_000_000

ENV_KWARGS = dict(
    season_length=150,
    max_irrigation=30.0,
    initial_soil_moisture=0.65,
)

# Training is always done under the "normal" weather regime.
# Cross-regime generalization is tested only at evaluation time
# (see evaluation/evaluate_all.py) -- the agent never sees
# drought/heatwave/excess_rain during learning.
TRAIN_REGIME = "normal"

# ---------------------------------------------------------------
# Per-algorithm hyperparameters
# ---------------------------------------------------------------

PPO_KWARGS = dict(
    policy="MlpPolicy",
    learning_rate=3e-4,
    n_steps=2048,
    batch_size=64,
    n_epochs=10,
    gamma=0.99,
    gae_lambda=0.95,
    clip_range=0.2,
    ent_coef=0.0,
    verbose=1,
)

SAC_KWARGS = dict(
    policy="MlpPolicy",
    learning_rate=3e-4,
    buffer_size=200_000,
    batch_size=256,
    gamma=0.99,
    tau=0.005,
    train_freq=1,
    gradient_steps=1,
    learning_starts=1_000,
    verbose=1,
)

A2C_KWARGS = dict(
    policy="MlpPolicy",
    learning_rate=7e-4,
    n_steps=5,
    gamma=0.99,
    gae_lambda=1.0,
    ent_coef=0.0,
    verbose=1,
)

DQN_KWARGS = dict(
    policy="MlpPolicy",
    learning_rate=1e-4,
    buffer_size=200_000,
    batch_size=64,
    gamma=0.99,
    train_freq=4,
    gradient_steps=1,
    target_update_interval=1_000,
    exploration_fraction=0.2,
    exploration_final_eps=0.02,
    learning_starts=1_000,
    verbose=1,
)

DISCRETE_LEVELS_MM = [0.0, 5.0, 10.0, 15.0, 20.0, 25.0, 30.0]

ALGO_KWARGS = {
    "ppo": PPO_KWARGS,
    "sac": SAC_KWARGS,
    "a2c": A2C_KWARGS,
    "dqn": DQN_KWARGS,
}


def model_dir(algo: str, seed: int) -> str:
    path = os.path.join(MODELS_DIR, algo, f"seed_{seed}")
    os.makedirs(path, exist_ok=True)
    return path


def tensorboard_dir(algo: str) -> str:
    path = os.path.join(TENSORBOARD_DIR, algo)
    os.makedirs(path, exist_ok=True)
    return path
