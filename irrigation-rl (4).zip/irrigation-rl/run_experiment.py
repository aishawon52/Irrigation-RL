"""
run_experiment.py

Single entry point for the full pipeline: train all algorithms/seeds,
evaluate across all regimes/baselines, run significance tests, and
generate all figures.

For real experiments you'll likely want to run training in the
background (it's the slow part) and re-run evaluation/plotting
separately as needed -- this script is provided mainly for a clean
end-to-end smoke test / reproducibility check.

Usage:
    python run_experiment.py --timesteps 500000 --n-episodes 20
    python run_experiment.py --skip-training   # re-run eval/plots only
"""

import argparse

from training.train_all import main as train_all
from training.config import SEEDS, TOTAL_TIMESTEPS
from evaluation.evaluate_all import main as evaluate_all
from evaluation.significance import main as run_significance
from plotting.degradation_plot import plot_degradation
from plotting.pareto_plot import plot_pareto
from plotting.learning_curves import plot_learning_curves


def main(timesteps: int, n_episodes: int, skip_training: bool):
    if not skip_training:
        print("\n### STAGE 1: TRAINING ###")
        train_all(algos=["ppo", "sac", "a2c", "dqn"], seeds=SEEDS, timesteps=timesteps)
    else:
        print("\n### STAGE 1: TRAINING (skipped) ###")

    print("\n### STAGE 2: EVALUATION ###")
    evaluate_all(n_episodes=n_episodes)

    print("\n### STAGE 3: SIGNIFICANCE TESTS ###")
    run_significance()

    print("\n### STAGE 4: FIGURES ###")
    plot_degradation(metric="yield_mean")
    plot_degradation(metric="water_productivity_mean")
    for regime in ["normal", "drought", "heatwave", "excess_rain"]:
        plot_pareto(regime=regime)
    plot_learning_curves()

    print("\nDone. See results/tables/ and results/figures/.")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--timesteps", type=int, default=TOTAL_TIMESTEPS)
    parser.add_argument("--n-episodes", type=int, default=20)
    parser.add_argument("--skip-training", action="store_true")
    args = parser.parse_args()
    main(timesteps=args.timesteps, n_episodes=args.n_episodes, skip_training=args.skip_training)
