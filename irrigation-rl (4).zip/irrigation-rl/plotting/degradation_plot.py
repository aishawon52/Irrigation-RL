"""
degradation_plot.py

Bar chart showing each RL algorithm's yield (or water productivity)
under each weather regime, normalized against its own "normal" regime
performance -- i.e. % degradation when moving out of distribution.
This is the key figure for the generalization research question.

Usage:
    python -m plotting.degradation_plot
"""

import os

import pandas as pd
import matplotlib.pyplot as plt
import numpy as np

from training.config import RESULTS_DIR

RL_ALGOS = ["ppo", "sac", "a2c", "dqn"]
REGIME_ORDER = ["normal", "drought", "heatwave", "excess_rain"]


def load_results():
    path = os.path.join(RESULTS_DIR, "tables", "full_results.csv")
    return pd.read_csv(path)


def compute_relative_performance(df: pd.DataFrame, metric: str = "yield_mean"):
    """For each algorithm, average across seeds per regime, then
    express each regime's value as a % of that algorithm's normal-
    regime value."""
    rl_df = df[df["method"].isin(RL_ALGOS)]
    grouped = rl_df.groupby(["method", "regime"])[metric].mean().reset_index()

    pivot = grouped.pivot(index="method", columns="regime", values=metric)
    pivot = pivot.reindex(columns=REGIME_ORDER)

    relative = pivot.div(pivot["normal"], axis=0) * 100.0
    return relative


def plot_degradation(metric: str = "yield_mean", save: bool = True):
    df = load_results()
    relative = compute_relative_performance(df, metric=metric)

    fig, ax = plt.subplots(figsize=(8, 5))
    x = np.arange(len(REGIME_ORDER))
    width = 0.8 / len(relative.index)

    for i, algo in enumerate(relative.index):
        values = relative.loc[algo, REGIME_ORDER].values
        ax.bar(x + i * width, values, width, label=algo.upper())

    ax.axhline(100, color="gray", linestyle="--", linewidth=1, label="Normal-regime baseline")
    ax.set_xticks(x + width * (len(relative.index) - 1) / 2)
    ax.set_xticklabels([r.replace("_", " ").title() for r in REGIME_ORDER])
    ax.set_ylabel(f"{metric} relative to normal regime (%)")
    ax.set_title("Cross-Regime Generalization: Performance Retention")
    ax.legend()
    fig.tight_layout()

    if save:
        out_dir = os.path.join(RESULTS_DIR, "figures")
        os.makedirs(out_dir, exist_ok=True)
        out_path = os.path.join(out_dir, f"degradation_{metric}.png")
        fig.savefig(out_path, dpi=200)
        print(f"Saved {out_path}")

    return fig


if __name__ == "__main__":
    plot_degradation(metric="yield_mean")
    plot_degradation(metric="water_productivity_mean")
