"""
learning_curves.py

Plots training reward curves for all algorithms (averaged across
seeds, with a shaded std band) directly from SB3's Monitor CSV logs
(models/{algo}/seed_{n}/{rank}.monitor.csv, one file per parallel
sub-env), which is simpler and more portable than parsing
TensorBoard's binary event files. The separate eval_monitor.csv
written by the periodic EvalCallback is intentionally excluded --
see _TRAIN_MONITOR_RE below. Use TensorBoard itself (see README) for
live/interactive inspection while training; use this script to
generate the static figure for the paper.

Usage:
    python -m plotting.learning_curves
"""

import glob
import os
import re

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

from training.config import SEEDS, MODELS_DIR, RESULTS_DIR

ALGOS = ["ppo", "sac", "a2c", "dqn"]

# Matches the *training*-env monitor files written by env_factory.py,
# e.g. "0.monitor.csv", "1.monitor.csv" (one per parallel sub-env, rank
# 0..n_envs-1) -- and nothing else. This deliberately excludes
# "eval_monitor.csv" (the separate, single periodic-eval env used by
# EvalCallback): mixing its sparse, deterministic-policy episodes in
# with the noisy training episodes would distort the training curve,
# and it also excludes any bare "monitor.csv" that isn't rank-prefixed.
_TRAIN_MONITOR_RE = re.compile(r"^\d+\.monitor\.csv$")


def _load_monitor_file(path: str) -> pd.DataFrame:
    """Read one SB3 Monitor CSV. Line 1 is a JSON metadata comment
    (starts with '#'), line 2 is the header ('r,l,t,...'), the rest is
    data -- so skip the comment line and let pandas read the header."""
    return pd.read_csv(path, skiprows=1)


def load_algo_curve(algo: str, seeds=SEEDS, n_points: int = 200):
    """Load and resample each seed's training-env monitor CSVs onto a
    common timestep grid, then return (x, mean, std)."""
    curves = []
    max_timesteps = 0

    for seed in seeds:
        log_dir = os.path.join(MODELS_DIR, algo, f"seed_{seed}")
        if not os.path.isdir(log_dir):
            print(f"[skip] no directory for {algo} seed={seed}")
            continue

        monitor_files = [
            f for f in glob.glob(os.path.join(log_dir, "*.monitor.csv"))
            if _TRAIN_MONITOR_RE.match(os.path.basename(f))
        ]
        if not monitor_files:
            print(f"[skip] no training monitor CSVs for {algo} seed={seed} "
                  f"(looked in {log_dir})")
            continue

        try:
            # Concatenate every parallel sub-env's episodes, then sort
            # by wall-clock time 't' to interleave them into roughly
            # chronological order -- same convention SB3's own
            # load_results()/ts2xy() use for vectorized training.
            dfs = [_load_monitor_file(f) for f in monitor_files]
            combined = pd.concat(dfs, ignore_index=True).sort_values("t")
            if len(combined) == 0:
                continue
            x = np.cumsum(combined["l"].values)
            y = combined["r"].values
            curves.append((x, y))
            max_timesteps = max(max_timesteps, x[-1])
        except Exception as e:
            print(f"[skip] {algo} seed={seed}: {e}")

    if not curves:
        return None, None, None

    grid = np.linspace(0, max_timesteps, n_points)
    interpolated = []
    for x, y in curves:
        interpolated.append(np.interp(grid, x, y))

    interpolated = np.array(interpolated)
    return grid, interpolated.mean(axis=0), interpolated.std(axis=0)


def plot_learning_curves(save: bool = True):
    fig, ax = plt.subplots(figsize=(9, 6))

    for algo in ALGOS:
        grid, mean, std = load_algo_curve(algo)
        if grid is None:
            continue
        ax.plot(grid, mean, label=algo.upper())
        ax.fill_between(grid, mean - std, mean + std, alpha=0.2)

    ax.set_xlabel("Training timesteps")
    ax.set_ylabel("Episode reward")
    ax.set_title("Training Curves (mean \u00b1 std across seeds)")
    ax.legend()
    fig.tight_layout()

    if save:
        out_dir = os.path.join(RESULTS_DIR, "figures")
        os.makedirs(out_dir, exist_ok=True)
        out_path = os.path.join(out_dir, "learning_curves.png")
        fig.savefig(out_path, dpi=200)
        print(f"Saved {out_path}")

    return fig


if __name__ == "__main__":
    plot_learning_curves()
