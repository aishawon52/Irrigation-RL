"""
pareto_plot.py

Scatter plot of yield vs. water used across all methods (RL
algorithms, baselines, observed practice), one regime at a time.
Highlights the Pareto frontier (high yield, low water) which is the
central trade-off claim of the paper.

Usage:
    python -m plotting.pareto_plot --regime normal
"""

import argparse
import os

import pandas as pd
import matplotlib.pyplot as plt

from training.config import RESULTS_DIR


def load_results():
    path = os.path.join(RESULTS_DIR, "tables", "full_results.csv")
    return pd.read_csv(path)


def pareto_frontier(points):
    """points: list of (water, yield, label). Returns the subset on
    the Pareto frontier (minimize water, maximize yield)."""
    points_sorted = sorted(points, key=lambda p: p[0])
    frontier = []
    best_yield = -float("inf")
    for water, yield_, label in points_sorted:
        if yield_ > best_yield:
            frontier.append((water, yield_, label))
            best_yield = yield_
    return frontier


def plot_pareto(regime: str = "normal", save: bool = True):
    df = load_results()
    regime_df = df[df["regime"] == regime]

    if regime_df.empty:
        print(f"No rows found for regime='{regime}'. Available regimes: "
              f"{df['regime'].dropna().unique().tolist()}")
        return None

    # One point per method: average across seeds if RL, single row if baseline.
    summary = regime_df.groupby("method")[["water_used_mean", "yield_mean"]].mean().reset_index()

    fig, ax = plt.subplots(figsize=(7, 6))
    ax.scatter(summary["water_used_mean"], summary["yield_mean"], s=80)

    for _, row in summary.iterrows():
        ax.annotate(row["method"], (row["water_used_mean"], row["yield_mean"]),
                    textcoords="offset points", xytext=(6, 4), fontsize=9)

    points = list(zip(summary["water_used_mean"], summary["yield_mean"], summary["method"]))
    frontier = pareto_frontier(points)
    frontier_sorted = sorted(frontier, key=lambda p: p[0])
    if len(frontier_sorted) > 1:
        fx = [p[0] for p in frontier_sorted]
        fy = [p[1] for p in frontier_sorted]
        ax.plot(fx, fy, linestyle="--", color="red", linewidth=1.5, label="Pareto frontier")
        ax.legend()

    ax.set_xlabel("Total water applied (mm)")
    ax.set_ylabel("Final yield")
    ax.set_title(f"Yield vs. Water Trade-off ({regime.replace('_', ' ').title()} Regime)")
    fig.tight_layout()

    if save:
        out_dir = os.path.join(RESULTS_DIR, "figures")
        os.makedirs(out_dir, exist_ok=True)
        out_path = os.path.join(out_dir, f"pareto_{regime}.png")
        fig.savefig(out_path, dpi=200)
        print(f"Saved {out_path}")

    return fig


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--regime", default="normal")
    args = parser.parse_args()
    plot_pareto(regime=args.regime)
