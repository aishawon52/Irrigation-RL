"""
observed_practice.py

Real-world benchmark: replays an actual recorded irrigation schedule
(from a field dataset) through IrrigationEnv day by day, so that its
resulting yield/water/stress metrics are computed under exactly the
same simulator as the RL policies and other baselines.

This is NOT a policy in the RL sense (it does not react to the
environment's state) -- it deterministically follows the historical
record. It is deliberately kept structurally separate from the
reactive baselines (fixed/threshold/random) for that reason; see the
evaluation harness for how it's invoked differently (day-indexed
rather than state-indexed).

Expected input: a list/array of daily irrigation amounts (mm), one
per day of the season, e.g. loaded via data/loaders.py from a real
dataset's irrigation records.
"""

import numpy as np


class ObservedPracticePolicy:
    """Replays a fixed, pre-recorded sequence of daily irrigation
    amounts. Ignores the observation entirely (open-loop control)."""

    def __init__(self, irrigation_series):
        self.irrigation_series = list(irrigation_series)
        self._day = 0

    def reset(self):
        self._day = 0

    def predict(self, observation, deterministic=True):
        idx = min(self._day, len(self.irrigation_series) - 1)
        mm = self.irrigation_series[idx]
        self._day += 1
        return np.array([mm], dtype=np.float32), None
