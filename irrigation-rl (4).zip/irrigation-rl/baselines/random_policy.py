"""Random irrigation baseline: uniform random mm/day within bounds."""

import numpy as np


class RandomPolicy:
    def __init__(self, max_irrigation: float = 30.0, seed: int | None = None):
        self.max_irrigation = max_irrigation
        self.rng = np.random.default_rng(seed)

    def predict(self, observation, deterministic=True):
        action = np.array(
            [self.rng.uniform(0.0, self.max_irrigation)], dtype=np.float32
        )
        return action, None
