"""
Threshold irrigation baseline.

Irrigates a fixed amount whenever soil moisture drops below a
threshold; otherwise applies nothing. Soil moisture is observation
index 0 (see IrrigationEnv._get_observation).
"""

import numpy as np


class ThresholdPolicy:
    def __init__(self, moisture_threshold: float = 0.40, irrigation_amount: float = 15.0):
        self.moisture_threshold = moisture_threshold
        self.irrigation_amount = irrigation_amount

    def predict(self, observation, deterministic=True):
        soil_moisture = observation[0]
        if soil_moisture < self.moisture_threshold:
            action = np.array([self.irrigation_amount], dtype=np.float32)
        else:
            action = np.array([0.0], dtype=np.float32)
        return action, None
