"""Fixed irrigation baseline: apply a constant mm/day regardless of state."""

import numpy as np


class FixedPolicy:
    """Applies the same irrigation amount every day."""

    def __init__(self, mm_per_day: float = 10.0):
        self.mm_per_day = mm_per_day

    def predict(self, observation, deterministic=True):
        # Mimic SB3's model.predict(obs) -> (action, state) interface
        # so the same evaluation rollout code works for baselines too.
        action = np.array([self.mm_per_day], dtype=np.float32)
        return action, None
