"""
fix_water_productivity_and_regenerate.py

Run this once from the project root (irrigation-rl/) to:
  1. Patch the water_productivity bug directly in envs/irrigation_env.py
     and evaluation/metrics.py (safe to run even if already patched --
     it checks first and skips if so).
  2. Re-run evaluation on your EXISTING trained models in models/ --
     no retraining needed, since the bug was only in how a metric was
     computed during evaluation rollouts, not in training itself.
  3. Regenerate results/tables/full_results.csv, the significance
     tables, and every figure in results/figures/.

Usage (from the irrigation-rl project root, with your venv active):
    python fix_water_productivity_and_regenerate.py
    python fix_water_productivity_and_regenerate.py --n-episodes 20
"""

import argparse
import os
import sys

# --- Step 1: patch the two source files in place -----------------------

ENV_FILE = os.path.join("envs", "irrigation_env.py")
METRICS_FILE = os.path.join("evaluation", "metrics.py")

OLD_ENV_SNIPPET = '''            info["water_productivity"] = (
                info["final_yield"] / max(self.cumulative_water, 1e-6)
            )'''

NEW_ENV_SNIPPET = '''            # water_productivity (yield per mm applied) is only a
            # meaningful ratio when meaningful irrigation actually
            # happened. Below MIN_WATER_FOR_PRODUCTIVITY mm, yield came
            # almost entirely from rainfall, and dividing by a
            # near-zero denominator produces an arbitrarily large
            # ratio that swamps any mean taken across episodes -- this
            # is a metric artifact, not evidence of water efficiency.
            # Report NaN instead so downstream aggregation (see
            # evaluation/metrics.py) can exclude these episodes
            # explicitly rather than silently being dominated by them.
            MIN_WATER_FOR_PRODUCTIVITY = 5.0  # mm, over the whole season
            if self.cumulative_water < MIN_WATER_FOR_PRODUCTIVITY:
                info["water_productivity"] = np.nan
            else:
                info["water_productivity"] = info["final_yield"] / self.cumulative_water'''

OLD_METRICS_SNIPPET = '''    yields = np.array([m["yield"] for m in episode_metric_dicts], dtype=float)
    summary["pct_below_viable_yield"] = float(
        100.0 * np.mean(yields < MIN_VIABLE_YIELD)
    )
    summary["n_episodes"] = len(episode_metric_dicts)
    return summary'''

NEW_METRICS_SNIPPET = '''    yields = np.array([m["yield"] for m in episode_metric_dicts], dtype=float)
    summary["pct_below_viable_yield"] = float(
        100.0 * np.mean(yields < MIN_VIABLE_YIELD)
    )

    # water_productivity is NaN for episodes where cumulative_water was
    # below MIN_WATER_FOR_PRODUCTIVITY (see IrrigationEnv.step) --
    # nanmean/nanstd above already exclude these correctly, but report
    # how many were excluded so a policy that skips irrigation in most
    # episodes is visible in the table rather than silently dropped.
    wp_values = np.array([m["water_productivity"] for m in episode_metric_dicts], dtype=float)
    summary["pct_negligible_water"] = float(100.0 * np.mean(np.isnan(wp_values)))

    summary["n_episodes"] = len(episode_metric_dicts)
    return summary'''


def patch_file(path: str, old_snippet: str, new_snippet: str, label: str) -> None:
    if not os.path.exists(path):
        print(f"[SKIP] {path} not found -- are you running this from the project root?")
        sys.exit(1)

    with open(path, "r", encoding="utf-8") as f:
        content = f.read()

    if new_snippet in content:
        print(f"[OK] {label} already patched, nothing to do.")
        return

    if old_snippet not in content:
        print(f"[WARN] {label}: couldn't find the expected old code in {path}.")
        print("       The file may already differ from what this script expects.")
        print("       Skipping this file -- check it manually.")
        return

    content = content.replace(old_snippet, new_snippet)
    with open(path, "w", encoding="utf-8") as f:
        f.write(content)
    print(f"[FIXED] {label} patched in {path}")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--n-episodes", type=int, default=20)
    args = parser.parse_args()

    print("### STEP 1: Patching source files ###")
    patch_file(ENV_FILE, OLD_ENV_SNIPPET, NEW_ENV_SNIPPET,
               "water_productivity computation (envs/irrigation_env.py)")
    patch_file(METRICS_FILE, OLD_METRICS_SNIPPET, NEW_METRICS_SNIPPET,
               "pct_negligible_water diagnostic (evaluation/metrics.py)")

    # Import AFTER patching, so Python picks up the patched files fresh
    print("\n### STEP 2: Re-evaluating existing trained models (no retraining) ###")
    from evaluation.evaluate_all import main as evaluate_all
    evaluate_all(n_episodes=args.n_episodes)

    print("\n### STEP 3: Re-running significance tests ###")
    from evaluation.significance import main as run_significance
    run_significance()

    print("\n### STEP 4: Regenerating figures ###")
    from plotting.degradation_plot import plot_degradation
    from plotting.pareto_plot import plot_pareto
    from plotting.learning_curves import plot_learning_curves

    plot_degradation(metric="yield_mean")
    plot_degradation(metric="water_productivity_mean")
    for regime in ["normal", "drought", "heatwave", "excess_rain"]:
        plot_pareto(regime=regime)
    plot_learning_curves()

    print("\nDone. Check results/tables/full_results.csv and results/figures/ "
          "for the corrected water_productivity numbers.")


if __name__ == "__main__":
    main()
