"""
irrigation_env.py

Daily crop-soil water balance environment for RL-based irrigation
scheduling. One episode = one growing season, one step = one day.

This is a modified version of the original IrrigationEnv with two
changes needed for the generalization study:

1. Weather generation is factored out into `_generate_weather`, which
   reads its distribution parameters from `self.weather_params`. This
   dict can be overwritten between episodes (see weather_regimes.py)
   to simulate drought / heatwave / excess-rainfall regimes without
   touching the core water-balance / growth / reward logic.

2. Soil parameters (field_capacity, wilting_point) and weather
   parameters are constructor arguments rather than hardcoded, so the
   same class can be calibrated against real data later without
   editing the class body.

Observation:
    [soil_moisture, temperature, rainfall, evapotranspiration,
     relative_humidity, crop_growth_stage, water_stress,
     previous_irrigation, cumulative_water]

Action:
    Continuous irrigation amount in mm/day, shape (1,).

Designed for Gymnasium + Stable-Baselines3 (PPO, SAC, A2C; DQN via
the discretizing wrapper in discrete_wrapper.py).
"""

import numpy as np
import gymnasium as gym
from gymnasium import spaces


# Default weather-distribution parameters. These represent the
# "normal" training regime. Regimes in weather_regimes.py are defined
# as overrides on top of this dict.
DEFAULT_WEATHER_PARAMS = {
    "temp_base": 25.0,          # deg C, seasonal mean
    "temp_amplitude": 7.0,      # deg C, seasonal swing
    "temp_noise_std": 2.0,

    "humidity_base": 70.0,
    "humidity_noise_std": 5.0,

    "rain_prob": 0.20,          # probability of a rain event on a given day
    "rain_gamma_shape": 2.0,
    "rain_gamma_scale": 5.0,
    "rain_max": 50.0,

    "et_base": 2.5,
    "et_temp_coef": 0.20,
    "et_noise_std": 0.5,
    "et_min": 1.0,
    "et_max": 10.0,
}


class IrrigationEnv(gym.Env):
    """Simple agricultural irrigation environment with pluggable weather."""

    metadata = {"render_modes": ["human"]}

    def __init__(
        self,
        season_length=150,
        max_irrigation=30.0,
        initial_soil_moisture=0.65,
        field_capacity=1.0,
        wilting_point=0.15,
        weather_params=None,
        weather_series=None,
        reward_weights=None,
        seed=None,
        render_mode=None,
    ):
        """
        Parameters
        ----------
        weather_params : dict or None
            Overrides for DEFAULT_WEATHER_PARAMS. Used for synthetic
            regime generation (normal/drought/heatwave/excess_rain).
            Ignored if weather_series is provided.
        weather_series : list[dict] or None
            If provided, weather is replayed from real/pre-generated
            daily records instead of sampled stochastically. Each
            dict must have keys: temperature, rainfall,
            evapotranspiration, humidity. Length must be >=
            season_length. Used for the real-practice benchmark and
            for calibrated real-data experiments.
        reward_weights : dict or None
            Overrides for the reward function coefficients
            (growth, water, stress, drainage, yield_terminal).
        """
        super().__init__()

        self.season_length = season_length
        self.max_irrigation = max_irrigation
        self.initial_soil_moisture = initial_soil_moisture
        self.render_mode = render_mode

        self.field_capacity = field_capacity
        self.wilting_point = wilting_point

        self.weather_params = dict(DEFAULT_WEATHER_PARAMS)
        if weather_params:
            self.weather_params.update(weather_params)

        self.weather_series = weather_series

        self.reward_weights = {
            "growth": 10.0,
            "water": 0.10,
            "stress": 2.0,
            "drainage": 1.0,
            "yield_terminal": 20.0,
        }
        if reward_weights:
            self.reward_weights.update(reward_weights)

        # Action space: irrigation amount in mm/day
        self.action_space = spaces.Box(
            low=np.array([0.0], dtype=np.float32),
            high=np.array([self.max_irrigation], dtype=np.float32),
            dtype=np.float32,
        )

        # Observation space
        self.observation_space = spaces.Box(
            low=np.array([
                0.0, -10.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0
            ], dtype=np.float32),
            high=np.array([
                1.0, 60.0, 100.0, 20.0, 100.0, 1.0, 1.0,
                max_irrigation, season_length * max_irrigation
            ], dtype=np.float32),
        )

        # Internal state
        self.day = 0
        self.soil_moisture = 0.0
        self.previous_irrigation = 0.0
        self.cumulative_water = 0.0
        self.crop_biomass = 0.0
        self.cumulative_stress = 0.0
        self.cumulative_drainage = 0.0
        self.temperature = 0.0
        self.rainfall = 0.0
        self.evapotranspiration = 0.0
        self.humidity = 0.0

        self.rng = np.random.default_rng(seed)

    # =============================================================
    # RESET
    # =============================================================

    def reset(self, *, seed=None, options=None):
        super().reset(seed=seed)

        if seed is not None:
            self.rng = np.random.default_rng(seed)

        self.day = 0

        self.soil_moisture = np.clip(
            self.initial_soil_moisture + self.rng.normal(0, 0.03),
            self.wilting_point,
            self.field_capacity,
        )

        self.previous_irrigation = 0.0
        self.cumulative_water = 0.0
        self.crop_biomass = 0.0
        self.cumulative_stress = 0.0
        self.cumulative_drainage = 0.0

        self._generate_weather()

        observation = self._get_observation()
        info = {
            "day": self.day,
            "soil_moisture": self.soil_moisture,
            "crop_biomass": self.crop_biomass,
        }
        return observation, info

    # =============================================================
    # WEATHER MODEL
    # =============================================================

    def _generate_weather(self):
        """Populate today's weather. Uses weather_series if provided
        (real/pre-generated replay), otherwise samples stochastically
        from self.weather_params (synthetic regime generation)."""

        if self.weather_series is not None:
            self._weather_from_series()
        else:
            self._weather_from_params()

    def _weather_from_series(self):
        idx = min(self.day, len(self.weather_series) - 1)
        record = self.weather_series[idx]
        self.temperature = record["temperature"]
        self.rainfall = record["rainfall"]
        self.evapotranspiration = record["evapotranspiration"]
        self.humidity = record["humidity"]

    def _weather_from_params(self):
        p = self.weather_params
        season_fraction = self.day / self.season_length

        base_temperature = (
            p["temp_base"] + p["temp_amplitude"] * np.sin(np.pi * season_fraction)
        )
        self.temperature = base_temperature + self.rng.normal(0, p["temp_noise_std"])

        self.humidity = np.clip(
            p["humidity_base"]
            - 0.8 * (self.temperature - p["temp_base"])
            + self.rng.normal(0, p["humidity_noise_std"]),
            20.0, 100.0,
        )

        if self.rng.random() < p["rain_prob"]:
            self.rainfall = self.rng.gamma(
                shape=p["rain_gamma_shape"], scale=p["rain_gamma_scale"]
            )
            self.rainfall = min(self.rainfall, p["rain_max"])
        else:
            self.rainfall = 0.0

        self.evapotranspiration = np.clip(
            p["et_base"]
            + p["et_temp_coef"] * (self.temperature - 20.0)
            + self.rng.normal(0, p["et_noise_std"]),
            p["et_min"], p["et_max"],
        )

    # =============================================================
    # CROP WATER STRESS
    # =============================================================

    def _calculate_water_stress(self):
        available_water = (
            (self.soil_moisture - self.wilting_point)
            / (self.field_capacity - self.wilting_point)
        )
        available_water = np.clip(available_water, 0.0, 1.0)
        return 1.0 - available_water

    # =============================================================
    # CROP GROWTH
    # =============================================================

    def _calculate_growth(self, stress):
        stage = self.day / self.season_length
        growth_factor = max(np.sin(np.pi * stage), 0.0)
        water_response = 1.0 - stress
        potential_growth = 1.0 * growth_factor
        return potential_growth * water_response

    # =============================================================
    # STEP
    # =============================================================

    def step(self, action):
        irrigation = float(np.clip(action[0], 0.0, self.max_irrigation))

        rainfall = self.rainfall
        evapotranspiration = self.evapotranspiration
        previous_moisture = self.soil_moisture

        water_before_drainage = (
            previous_moisture
            + rainfall / 100.0
            + irrigation / 100.0
            - evapotranspiration / 100.0
        )

        drainage = max(water_before_drainage - self.field_capacity, 0.0)

        self.soil_moisture = np.clip(
            water_before_drainage, 0.0, self.field_capacity
        )

        stress = self._calculate_water_stress()
        growth = self._calculate_growth(stress)
        self.crop_biomass += growth

        self.cumulative_water += irrigation
        self.cumulative_stress += stress
        self.cumulative_drainage += drainage * 100.0
        self.previous_irrigation = irrigation

        w = self.reward_weights
        growth_reward = w["growth"] * growth
        water_penalty = w["water"] * irrigation
        stress_penalty = w["stress"] * stress
        drainage_penalty = w["drainage"] * drainage * 100.0

        reward = growth_reward - water_penalty - stress_penalty - drainage_penalty

        self.day += 1
        terminated = self.day >= self.season_length
        truncated = False

        if terminated:
            final_yield = self._calculate_yield()
            reward += w["yield_terminal"] * final_yield

        if not terminated:
            self._generate_weather()

        observation = self._get_observation()

        info = {
            "day": self.day,
            "soil_moisture": self.soil_moisture,
            "temperature": self.temperature,
            "rainfall": self.rainfall,
            "evapotranspiration": self.evapotranspiration,
            "water_stress": stress,
            "irrigation": irrigation,
            "cumulative_water": self.cumulative_water,
            "crop_biomass": self.crop_biomass,
            "drainage": drainage,
        }

        if terminated:
            info["final_yield"] = self._calculate_yield()
            # water_productivity (yield per mm applied) is only a
            # meaningful ratio when meaningful irrigation actually
            # happened. Below MIN_WATER_FOR_PRODUCTIVITY mm, yield came
            # almost entirely from rainfall, and dividing by a
            # near-zero denominator produces an arbitrarily large
            # ratio that swamps any mean taken across episodes -- this
            # is a metric artifact, not evidence of water efficiency.
            # Report NaN instead so downstream aggregation (see
            # evaluation/metrics.py) can exclude these episodes
            # explicitly rather than silently being dominated by them.
            MIN_WATER_FOR_PRODUCTIVITY = 5.0  # mm, over the whole season
            if self.cumulative_water < MIN_WATER_FOR_PRODUCTIVITY:
                info["water_productivity"] = np.nan
            else:
                info["water_productivity"] = info["final_yield"] / self.cumulative_water
            info["cumulative_stress"] = self.cumulative_stress
            info["cumulative_drainage"] = self.cumulative_drainage

        if self.render_mode == "human":
            self.render()

        return observation, float(reward), terminated, truncated, info

    # =============================================================
    # OBSERVATION
    # =============================================================

    def _get_observation(self):
        growth_stage = self.day / self.season_length
        water_stress = self._calculate_water_stress()

        return np.array([
            self.soil_moisture,
            self.temperature,
            self.rainfall,
            self.evapotranspiration,
            self.humidity,
            growth_stage,
            water_stress,
            self.previous_irrigation,
            self.cumulative_water,
        ], dtype=np.float32)

    # =============================================================
    # YIELD MODEL
    # =============================================================

    def _calculate_yield(self):
        stress_factor = self.cumulative_stress / max(self.season_length, 1)
        yield_value = self.crop_biomass * (1.0 - 0.5 * stress_factor)
        return max(yield_value, 0.0)

    # =============================================================
    # RENDER / CLOSE
    # =============================================================

    def render(self):
        print(
            f"Day: {self.day:3d} | Soil: {self.soil_moisture:.3f} | "
            f"Rain: {self.rainfall:.2f} mm | ET: {self.evapotranspiration:.2f} mm | "
            f"Irrigation: {self.previous_irrigation:.2f} mm | "
            f"Stress: {self._calculate_water_stress():.3f}"
        )

    def close(self):
        pass
