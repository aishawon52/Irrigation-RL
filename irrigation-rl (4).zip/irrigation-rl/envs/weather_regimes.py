"""
weather_regimes.py

Defines synthetic weather regimes as parameter overrides on top of
IrrigationEnv's DEFAULT_WEATHER_PARAMS. Used to test whether a policy
trained under "normal" weather generalizes to unseen conditions.

Regimes are deliberately expressed as *relative* perturbations of the
default so that tightening/loosening severity later is a one-line
change, and so the same structure can later be re-parameterized from
real historical weather statistics if you calibrate against a dataset.
"""

from copy import deepcopy
from envs.irrigation_env import DEFAULT_WEATHER_PARAMS


REGIMES = {
    "normal": {
        # no overrides -- identical to DEFAULT_WEATHER_PARAMS
    },
    "drought": {
        "rain_prob": 0.08,          # far fewer rain events
        "rain_gamma_scale": 3.0,    # smaller rain amounts when it does rain
        "rain_max": 25.0,
        "temp_base": 27.5,          # modestly hotter -> higher ET
        "et_base": 3.2,
    },
    "heatwave": {
        "temp_base": 30.0,          # +5 deg C vs default
        "temp_amplitude": 8.5,
        "et_base": 3.5,
        "et_temp_coef": 0.28,
        "humidity_base": 55.0,
    },
    "excess_rain": {
        "rain_prob": 0.38,          # roughly double rain frequency
        "rain_gamma_shape": 2.5,
        "rain_gamma_scale": 8.0,    # larger events
        "rain_max": 80.0,
        "humidity_base": 80.0,
    },
}


def get_weather_params(regime_name: str) -> dict:
    """Return a full weather_params dict for the given regime name,
    built by overlaying the regime's overrides on the defaults."""
    if regime_name not in REGIMES:
        raise ValueError(
            f"Unknown regime '{regime_name}'. Available: {list(REGIMES.keys())}"
        )
    params = deepcopy(DEFAULT_WEATHER_PARAMS)
    params.update(REGIMES[regime_name])
    return params


def apply_regime(env, regime_name: str):
    """Mutate an existing IrrigationEnv instance in-place to use the
    given regime's weather parameters. Call before env.reset()."""
    env.weather_params = get_weather_params(regime_name)
    env.weather_series = None  # ensure synthetic generation is used
    return env


def make_env_with_regime(regime_name: str, env_kwargs: dict | None = None):
    """Convenience factory: build a fresh IrrigationEnv configured for
    a given regime. env_kwargs are passed through to the constructor
    (season_length, max_irrigation, seed, etc.)."""
    from envs.irrigation_env import IrrigationEnv

    env_kwargs = dict(env_kwargs or {})
    env_kwargs["weather_params"] = get_weather_params(regime_name)
    return IrrigationEnv(**env_kwargs)
