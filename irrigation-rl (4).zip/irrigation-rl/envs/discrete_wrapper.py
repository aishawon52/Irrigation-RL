"""
discrete_wrapper.py

DQN requires a discrete action space, but IrrigationEnv's native
action space is continuous (Box). This wrapper exposes a Discrete(N)
action space to the agent and maps each discrete choice to a fixed
mm/day irrigation level before forwarding it to the underlying env.

Using a wrapper (rather than a second environment class) guarantees
that DQN is evaluated on exactly the same transition dynamics, reward
function, and observation space as PPO/SAC/A2C -- only the action
interface differs.
"""

import numpy as np
import gymnasium as gym
from gymnasium import spaces


DEFAULT_LEVELS_MM = [0.0, 5.0, 10.0, 15.0, 20.0, 25.0, 30.0]


class DiscreteIrrigationWrapper(gym.ActionWrapper):
    """Maps Discrete(len(levels_mm)) actions to fixed mm/day levels."""

    def __init__(self, env, levels_mm=None):
        super().__init__(env)
        self.levels_mm = list(levels_mm) if levels_mm is not None else list(DEFAULT_LEVELS_MM)

        max_irrigation = float(env.action_space.high[0])
        for level in self.levels_mm:
            if level > max_irrigation:
                raise ValueError(
                    f"Discrete level {level} exceeds env max_irrigation {max_irrigation}"
                )

        self.action_space = spaces.Discrete(len(self.levels_mm))

    def action(self, action):
        # action is an integer index into self.levels_mm
        mm = self.levels_mm[int(action)]
        return np.array([mm], dtype=np.float32)
